const colors = ['red'];
//colors.push('green');
console.log(colors); 

colors.pop();
colors.pop();
console.log(colors); // []

//colors = []; // TypeError