var uname = new String("Asmita");
console.log("Message: " + uname);
console.log("Length: " + uname.length);
